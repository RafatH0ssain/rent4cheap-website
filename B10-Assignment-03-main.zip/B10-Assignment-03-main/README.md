# B10-Assignment-03

[Figma Online View](https://www.figma.com/design/3LkLBGt1Te6JGZbWdpUUEU/Assignment-3?node-id=0-1&t=a9DWsljnqY8jDbxT-1)

[Assignment Resources - Google Drive](https://drive.google.com/drive/folders/1Y_awQ0SGrij6zdFo1bgxZndxbDkqGejU?usp=sharing)
